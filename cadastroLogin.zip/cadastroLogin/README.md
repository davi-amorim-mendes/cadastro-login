# Cadastro e Login
## ![Image](https://github.com/user-attachments/assets/f717d872-0689-457f-8783-09952d585217)
## Sobre:
Atividade de introdução a banco de dados.
## Funcionalidades:
- Cadastro de usuários
- Login via email e senha
- Logout
- Listar usuários
## Linguagens e tecnologias utilizadas:
[![My Skills](https://skillicons.dev/icons?i=html,css,php,mysql)](https://skillicons.dev)
- Html
- CSS
- PHP
- SQL
